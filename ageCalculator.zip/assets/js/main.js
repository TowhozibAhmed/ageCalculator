
const checkAge = document.querySelector('#checkAge');
const ageMessage = document.querySelector('.age__message');

let date = new Date();
let currentYear = date.getFullYear();

checkAge.addEventListener('click', () => {
    const name = document.querySelector('#name').value;
    const birthYear = document.querySelector('#birthYear').value;
    let currentAge = currentYear - birthYear;

    if (name == '' || birthYear == '') {

        ageMessage.innerHTML = `
    
        <p class="alert alert-danger">
            Enter Valid Information.
        </p>
    
    `
    } else {

        ageMessage.innerHTML = `
    
        <p class="alert alert-success">
            Hi ${name}. You are ${currentAge} years old. ${ageStatus(currentAge)}
        </p>
    
    `
    }
 
 


});

function ageStatus(currentAge) {
    if (currentAge < 0) {
        return 'You have not been born yet. Please wait.....';
    } else if (currentAge < 10) {
        return 'You are a Baby';
    }  else if (currentAge < 18) {
        return 'You are a Child';
    } else if (currentAge < 24) {
        return 'You are a Teenager';
    } else if (currentAge <= 35) {
        return 'You are a Jubok';
    } else if (currentAge > 35) {
        return 'You are an Adult';
    } else if (currentAge >= 50) {
        return 'You are a Bridhdho';
    } else if (currentAge >= 110) {
        return 'You are a Bhoot';
    }
}

